import { useDispatch, useSelector } from "react-redux"
import { increamentCake } from "./redux/slices/conterslice"



function IncreametCake(){

    const state=useSelector(state=>state)

    const dispatch = useDispatch()


    return(
        <>
        <button onClick={()=>{
            dispatch(increamentCake())
        }}>Increamet</button>
        <h5>{state.userDetails.name}</h5>
        </>
    )

}

export default IncreametCake