import { Component } from "react";
import { setStudentDetails } from "./redux/slices/studentDetailsSkice";
import { Connect, connect } from "react-redux";


class SudentDetail extends Component{

    constructor(){
        super()
        this.state={

        }
    }

    componentDidMount(){

        console.log(this.props.userDetails);

    }

    render(){

        const {name} = this.props.userDetails

        return(
            <>
            <h5>Name :{name}</h5>
            </>
        )

    }

}


const mapStateToProps=(state)=>{
    console.log(state);
    return {
        userDetails:state.userDetails
    }
}


const mapDispatchToProps = {
    
    userDetailsFun:(dispatch)=>dispatch(setStudentDetails({name:'Amir',age:'22',skills:[],address:'abc'}))
}

export default connect(mapStateToProps,mapDispatchToProps)(SudentDetail)