import { createSlice } from "@reduxjs/toolkit"

const initialState={
    name:'Amir khan',
    age:'',
    class:''
}


const userSlice = createSlice({
    name:'user',
    initialState,
    reducers:{
        setUserDetails:(state,action)=>{
            return{
                name:action.payload.name,
                age:action.payload.age,
                class:action.payload.class


            }
        }
    }
})

export const {setUserDetails} = userSlice.actions

export default userSlice.reducer