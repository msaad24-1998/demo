import { createSlice } from "@reduxjs/toolkit"



const initialState={
    studentDataFerched:false,
    name:"",
    age:'',
    skills:[],
    address:'',

}


const studentDetailsSlice = createSlice({
    name:'studentDetails',
    initialState,
    reducers:{
        setStudentDetails:(state,action)=>{
            return {
                name:action.payload.name,
                age:action.payload.age,
               skills:action.payload.skills,
                address:action.payload.address

            }
        }
    }
})

export const {setStudentDetails} = studentDetailsSlice.actions

export default studentDetailsSlice.reducer