import { createSlice } from "@reduxjs/toolkit"


const initialState={
    cake:0,
}

export const counterSlice=createSlice({
    name:'counter',
    initialState : initialState,
    reducers: {
        increamentCake:(state)=>{
           state.cake+=1 
        },
        decreamen:(state)=>{
            state.cake-=1;
        }
    }
})

export const {increamentCake} = counterSlice.actions

export default counterSlice.reducer