import { configureStore } from "@reduxjs/toolkit";
import counterSlice from './slices/conterslice'
import userDetails from "./slices/userDetails";
import studentDetailsSlice from "./slices/studentDetailsSkice";

export const store =configureStore({
    reducer:{
        counter:counterSlice,
        userDetails,
        studentDetailsSlice
    }
})