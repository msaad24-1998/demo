import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { increamentCake } from "./redux/slices/conterslice"
import { setUserDetails } from "./redux/slices/userDetails"

function Cake(){

    const val= useSelector(state=>state)

    const dispatch = useDispatch()

    useEffect(()=>{

        //dispatch(increamentCake())

        console.log(val);

    },[])


    return (<>
    
    <div>
        <h1>Cake  : {val.counter.cake}</h1>
        <button onClick={()=>{

            
            dispatch(setUserDetails({
                name:'Amir',
                age:'21',
                class:'MCA 2nd Year'
            }))
        }}>Update</button>
    </div>

    </>)

}

export default Cake